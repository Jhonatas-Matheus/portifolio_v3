(() => {
var exports = {};
exports.id = 327;
exports.ids = [327];
exports.modules = {

/***/ 8038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 8704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 7897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 6786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 9274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 2781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 520:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ next_dist_compiled_react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_7__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2286);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5717);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8353);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7340);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9029);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2458);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4065);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_compiled_react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8378);

    const tree = {
        children: [
        '',
        {
        children: [
        'contact',
        {
        children: ['', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 5829, 23)), "/home/jmdevbr/projetos/for_me/for_deploy_and_production/2023/março/portifolio_v3/src/app/contact/page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 4838, 23)), "/home/jmdevbr/projetos/for_me/for_deploy_and_production/2023/março/portifolio_v3/src/app/layout.tsx"],
'loading': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9642)), "/home/jmdevbr/projetos/for_me/for_deploy_and_production/2023/março/portifolio_v3/src/app/loading.tsx"],
'head': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9758)), "/home/jmdevbr/projetos/for_me/for_deploy_and_production/2023/março/portifolio_v3/src/app/head.tsx"],
          
        }
      ]
      }.children;
    const pages = ["/home/jmdevbr/projetos/for_me/for_deploy_and_production/2023/março/portifolio_v3/src/app/contact/page.tsx"];

    
    
    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
  

/***/ }),

/***/ 8702:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3481))

/***/ }),

/***/ 5829:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__ default */ const { createProxy  } = __webpack_require__(1399);
module.exports = createProxy("/home/jmdevbr/projetos/for_me/for_deploy_and_production/2023/mar\xe7o/portifolio_v3/src/app/contact/page.tsx");


/***/ }),

/***/ 3481:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ ContactPage)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/render/dom/motion.mjs + 199 modules
var motion = __webpack_require__(925);
// EXTERNAL MODULE: ./node_modules/styled-components/dist/styled-components.cjs.js
var styled_components_cjs = __webpack_require__(3103);
;// CONCATENATED MODULE: ./src/app/contact/styles.ts


const StyledContactSection = (0,styled_components_cjs/* default */.ZP)(motion/* motion.div */.E.div)`
  width: 100%;
  /* background-color: green; */
  display: flex;
  flex-direction: column;
  /* min-height: min-content; */
  height: min-content;
  @media (min-width:768px){
    height: 100%;
  }
  .display-content {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    gap: 1rem;
    @media (min-width: 768px) {
      flex-direction: row;
    }
  }
  .left-side {
    display: flex;
    flex-direction: column;
    height: 40rem;
    /* flex-basis: 500%; */
    @media (min-width: 768px) {
      height: auto;
      flex-basis: 30%;
    }
    gap: 1rem;
  }
  .icon-container {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    background-color: rgb(51, 51, 51);
    flex-basis: 25%;
    width: 100%;
    h2 {
      font-size: 1rem;
    }
    svg {
      color: var(--primary-color);
    }
  }
  .right-side {
    flex-basis: 70%;
    /* background-color: blue; */
    padding: 1rem;
    display: flex;
    align-self: center;
    justify-content: center;
    /* height: 70%; */
    height: min-content;
    width: 100%;
    form {
      display: flex;
      flex-direction: column;
      @media (min-width:768px){
        flex-direction: row;
      }
      gap: 1rem;
    }
    .form-inputs {
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      gap: 1rem;
      input {
        padding: 1rem;
        background-color: transparent;
        border: 2px solid rgb(154,154,154) ;
        border-radius: 10px;
        color:rgb(154,154,154);
        &::placeholder{
          color:rgb(154,154,154);
        }
        &:focus{
          outline: none;
        }
      }
      button {
        background-color: transparent;
        height: min-content;
        padding: 1rem;
        border: 2px solid rgb(154,154,154) ;
        border-radius: 10px;
        text-align: center;
        /* line-height: -500%; */
        color: #fff;
        font-weight: 700;
        transition: .5s;
        &:hover{
          background-color: var(--primary-color);
          border: 2px solid var(--primary-color);
        }
      }
    }
    textarea{
        background-color: transparent;
        border: 2px solid rgb(154,154,154) ;
        border-radius: 10px;
        padding: 1rem;
        color: rgb(154,154,154);
        &:focus{
          outline: none;
        }
      }
  }
  .title-section {
    font-size: 1.5rem;
    margin-bottom: 2rem;
    margin-top: 2rem;
    span {
      color: var(--primary-color);
    }
  }
  .main {
    font-size: 2rem;
    margin-top: 0;
  }
  form {
    display: flex;
    flex-direction: column;
  }
  .container-msg{
    display: flex;
    flex-direction: column;
    justify-content: center;
  }
  .error-validation{
    color: red;
  }
`;

// EXTERNAL MODULE: ./node_modules/react-icons/md/index.esm.js
var index_esm = __webpack_require__(4348);
// EXTERNAL MODULE: ./node_modules/yup/index.js
var yup = __webpack_require__(8952);
// EXTERNAL MODULE: ./node_modules/react-hook-form/dist/index.esm.mjs
var dist_index_esm = __webpack_require__(1031);
// EXTERNAL MODULE: ./node_modules/@hookform/resolvers/yup/dist/yup.mjs + 1 modules
var dist_yup = __webpack_require__(9780);
;// CONCATENATED MODULE: ./src/app/contact/page.tsx









const formSchema = yup/* object */.Ry({
    name: yup/* string */.Z_().trim().required("O campo nome \xe9 obrigat\xf3rio"),
    email: yup/* string */.Z_().trim().email("O campo deve conter um e-mail v\xe1lido").required("O campo email \xe9 obrigat\xf3rio"),
    subject: yup/* string */.Z_().trim(),
    message: yup/* string */.Z_().trim().required("O campo \xe9 obrigat\xf3rio")
});
function ContactPage() {
    const { register , handleSubmit , formState: { errors  }  } = (0,dist_index_esm/* useForm */.cI)({
        resolver: (0,dist_yup/* yupResolver */.X)(formSchema)
    });
    const handleOnSubmit = (data)=>{
        sendMessage({
            ...data
        });
        console.log(data);
    };
    const sendMessage = (payload)=>{
        const text = encodeURI(`*Gostaria de marcar uma reunião: \n *Nome:* ${payload.name} \n *Assunto:* ${payload.subject} \n *Mensagem*: ${payload.message} \n *Email:* ${payload.email}`);
        window.open("https://api.whatsapp.com/send?phone=" + "+5584999336921" + "&text=" + text, "_blank");
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(StyledContactSection, {
        initial: {
            opacity: 0,
            y: 0,
            rotateY: 90
        },
        animate: {
            opacity: 1,
            y: 0,
            rotateY: 0
        },
        exit: {
            opacity: 0,
            y: 0,
            rotateY: 90
        },
        transition: {
            duration: 0.5
        },
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                className: "title-section main",
                children: [
                    "Fale ",
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: "Comigo"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "display-content",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "left-side",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "icon-container",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* MdLocationPin */.vcr, {
                                        size: 40
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        children: "Mossor\xf3"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "icon-container",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* MdPhone */.IXo, {
                                        size: 40
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        children: "(84) 9 9933-6921"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "icon-container",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* MdMail */.h6V, {
                                        size: 40
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        children: "jmdevbr@gmail.com"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "icon-container",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* MdCheckCircle */.ZSR, {
                                        size: 40
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        children: "Dispon\xedvel para Freelancer"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "right-side",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                            onSubmit: handleSubmit(handleOnSubmit),
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "form-inputs",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                            type: "text",
                                            placeholder: "Nome Completo",
                                            ...register("name")
                                        }),
                                        errors.name && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "error-validation",
                                            children: errors.name.message
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                            type: "text",
                                            placeholder: "Email",
                                            ...register("email")
                                        }),
                                        errors.email && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "error-validation",
                                            children: errors.email.message
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                            type: "text",
                                            placeholder: "Assunto",
                                            ...register("subject")
                                        }),
                                        errors.subject && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "error-validation",
                                            children: errors.subject.message
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            type: "submit",
                                            children: "Enviar"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "container-msg",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                                            id: "",
                                            cols: 30,
                                            rows: 10,
                                            placeholder: "Mensagem",
                                            ...register("message")
                                        }),
                                        errors.message && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "error-validation",
                                            children: errors.message.message
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [576,687,197], () => (__webpack_exec__(520)));
module.exports = __webpack_exports__;

})();