(() => {
var exports = {};
exports.id = 890;
exports.ids = [890];
exports.modules = {

/***/ 8038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 8704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 7897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 6786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 9274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 2781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 3090:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ next_dist_compiled_react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_7__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2286);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5717);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8353);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7340);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9029);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2458);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4065);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_compiled_react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8378);

    const tree = {
        children: [
        '',
        {
        children: [
        'resume',
        {
        children: ['', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 5992, 23)), "/home/jmdevbr/projetos/for_me/for_deploy_and_production/2023/março/portifolio_v3/src/app/resume/page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 4838, 23)), "/home/jmdevbr/projetos/for_me/for_deploy_and_production/2023/março/portifolio_v3/src/app/layout.tsx"],
'loading': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9642)), "/home/jmdevbr/projetos/for_me/for_deploy_and_production/2023/março/portifolio_v3/src/app/loading.tsx"],
'head': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9758)), "/home/jmdevbr/projetos/for_me/for_deploy_and_production/2023/março/portifolio_v3/src/app/head.tsx"],
          
        }
      ]
      }.children;
    const pages = ["/home/jmdevbr/projetos/for_me/for_deploy_and_production/2023/março/portifolio_v3/src/app/resume/page.tsx"];

    
    
    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
  

/***/ }),

/***/ 9962:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8772))

/***/ }),

/***/ 5992:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__ default */ const { createProxy  } = __webpack_require__(1399);
module.exports = createProxy("/home/jmdevbr/projetos/for_me/for_deploy_and_production/2023/mar\xe7o/portifolio_v3/src/app/resume/page.tsx");


/***/ }),

/***/ 8772:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ ResumePage)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/render/dom/motion.mjs + 199 modules
var motion = __webpack_require__(925);
// EXTERNAL MODULE: ./node_modules/styled-components/dist/styled-components.cjs.js
var styled_components_cjs = __webpack_require__(3103);
;// CONCATENATED MODULE: ./src/app/resume/styles.ts


const StyledResumeSection = (0,styled_components_cjs/* default */.ZP)(motion/* motion.div */.E.div)`
position: absolute;
top: 0;
left: 0;
@media (min-width: 1024px){
position: static;
}
.title-section {
    font-size: 1.5rem;
    margin-bottom: 2rem;
    margin-top: 2rem;
    span {
      color: var(--primary-color);
    }
  }
  .main{
    font-size: 2rem;
    margin-top: 0;
  }
width: 100%;
height: min-content;
.filter-timeline{
    display: flex;
    justify-content: center;
    gap: 1rem;
    margin-top: 2rem;
    @media (min-width: 1024px){
        margin-top: 0
    }
    button{
        color: #fff;
        border-radius: 10px;
        padding: 1rem;
        border: 1px solid #fff;
        background-color: transparent;
        cursor: pointer;
        transition: .5s;
        &:hover{
            background-color: var(--primary-color);
        }
    }
    .active{
        color: #fff !important;
        background-color: var(--primary-color);
    }
}
`;

// EXTERNAL MODULE: ./node_modules/react-vertical-timeline-component/dist-modules/index.js
var dist_modules = __webpack_require__(7142);
// EXTERNAL MODULE: ./node_modules/react-vertical-timeline-component/style.min.css
var style_min = __webpack_require__(5119);
// EXTERNAL MODULE: ./node_modules/react-icons/hi/index.esm.js
var index_esm = __webpack_require__(5655);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
// EXTERNAL MODULE: ./node_modules/react-icons/md/index.esm.js
var md_index_esm = __webpack_require__(4348);
;// CONCATENATED MODULE: ./src/app/resume/page.tsx








function ResumePage() {
    const [timeline, setTimeline] = (0,react_.useState)("professional");
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(StyledResumeSection, {
        initial: {
            opacity: 0,
            y: 0,
            rotateY: 90
        },
        animate: {
            opacity: 1,
            y: 0,
            rotateY: 0
        },
        exit: {
            opacity: 0,
            y: 0,
            rotateY: 90
        },
        transition: {
            duration: 0.5
        },
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                className: "title-section main",
                children: [
                    "Minha ",
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: "Trajet\xf3ria"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "filter-timeline",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        onClick: ()=>setTimeline("professional"),
                        className: timeline === "professional" ? "active" : "",
                        children: "Profissional"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        onClick: ()=>setTimeline("academic"),
                        className: timeline === "academic" ? "active" : "",
                        children: "Acad\xeamico"
                    })
                ]
            }),
            timeline === "professional" && /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
                initial: {
                    opacity: 0,
                    y: 0,
                    rotateY: 90
                },
                animate: {
                    opacity: 1,
                    y: 0,
                    rotateY: 0
                },
                exit: {
                    opacity: 0,
                    y: 0,
                    rotateY: 90
                },
                transition: {
                    duration: 0.5
                },
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dist_modules.VerticalTimeline, {
                    layout: "1-column-left",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dist_modules.VerticalTimelineElement, {
                            className: "vertical-timeline-element--work",
                            contentStyle: {
                                background: "rgb(174, 123, 24)",
                                color: "#fff"
                            },
                            contentArrowStyle: {
                                borderRight: "7px solid  rgb(33, 150, 243)"
                            },
                            date: "jan de 2023 - atual",
                            dateClassName: "date-timeline",
                            iconStyle: {
                                background: "rgb(174, 123, 24)",
                                color: "#fff"
                            },
                            icon: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* HiOutlineCode */.oT$, {}),
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                    className: "vertical-timeline-element-title",
                                    children: "Desenvolvedor Full-Stack (Freelancer)"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                    children: "Paga Pix"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                    className: "vertical-timeline-element-subtitle",
                                    children: "Natal, RN"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Desenvolvimento de aplica\xe7\xe3o web utilizando o Framework Angular 2+ (NgRx - Typescript - Sass);"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Configura\xe7\xe3o de VPS e deploy de aplica\xe7\xe3o;"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Adapta\xe7\xe3o e corre\xe7\xe3o de bugs de back-end utilizando NodeJS (Webhooks, SocketIO, Telegram API)."
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dist_modules.VerticalTimelineElement, {
                            className: "vertical-timeline-element--work box-timeline",
                            contentStyle: {
                                background: "rgb(174, 123, 24)",
                                color: "#fff"
                            },
                            contentArrowStyle: {
                                borderRight: "7px solid  rgb(33, 150, 243)"
                            },
                            date: "dez de 2022 - fev de 2023",
                            dateClassName: "date-timeline",
                            iconStyle: {
                                background: "rgb(174, 123, 24)",
                                color: "#fff"
                            },
                            icon: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* HiOutlineCode */.oT$, {}),
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                    className: "vertical-timeline-element-title",
                                    children: "Desenvolvedor Full-Stack (Freelancer)"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                    children: "Orismar Viagens e encomendas"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                    className: "vertical-timeline-element-subtitle",
                                    children: "Mossor\xf3, RN"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Desenvolvimento de aplica\xe7\xe3o web utilizando o framework ReactJS (Context-API - Typescript- Styled Components - Framer Motion)."
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Configura\xe7\xe3o de VPS e deploy de aplica\xe7\xe3o;"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dist_modules.VerticalTimelineElement, {
                            className: "vertical-timeline-element--work box-timeline",
                            contentStyle: {
                                background: "rgb(174, 123, 24)",
                                color: "#fff"
                            },
                            contentArrowStyle: {
                                borderRight: "7px solid  rgb(33, 150, 243)"
                            },
                            date: "jul de 2022 - set de 2022",
                            dateClassName: "date-timeline",
                            iconStyle: {
                                background: "rgb(174, 123, 24)",
                                color: "#fff"
                            },
                            icon: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* HiOutlineCode */.oT$, {}),
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                    className: "vertical-timeline-element-title",
                                    children: "Monitor de ensino (Tempor\xe1rio)"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                    children: "Kenzie Academy Brasil"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                    className: "vertical-timeline-element-subtitle",
                                    children: "Curitiba, PR"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Supervisionamento direto de alunos do curso de Developer Full-Stack;"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Corre\xe7\xe3o de atividades de alunos do curso de Developer Full-Stack;"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Auxilio e code review para alunos do curso de Developer Full-Stack (Javascript - Typescript - ReactJS - NodeJS)."
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dist_modules.VerticalTimelineElement, {
                            className: "vertical-timeline-element--work box-timeline",
                            contentStyle: {
                                background: "rgb(174, 123, 24)",
                                color: "#fff"
                            },
                            contentArrowStyle: {
                                borderRight: "7px solid  rgb(33, 150, 243)"
                            },
                            date: "jul de 2018 - mai de 2022",
                            dateClassName: "date-timeline",
                            iconStyle: {
                                background: "rgb(174, 123, 24)",
                                color: "#fff"
                            },
                            icon: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* HiOutlineCode */.oT$, {}),
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                    className: "vertical-timeline-element-title",
                                    children: "T\xe9cnico de manuten\xe7\xe3o de computadores e notebooks"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                    children: "Jhontec"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                    className: "vertical-timeline-element-subtitle",
                                    children: "Mossor\xf3, PR"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Manuten\xe7\xe3o preventiva de computadores e notebooks;"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Formata\xe7\xe3o, troca de pe\xe7as(hardware) em geral"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Reparo de placas-m\xe3e"
                                })
                            ]
                        })
                    ]
                })
            }),
            timeline === "academic" && /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
                initial: {
                    opacity: 0,
                    y: 0,
                    rotateY: 90
                },
                animate: {
                    opacity: 1,
                    y: 0,
                    rotateY: 0
                },
                exit: {
                    opacity: 0,
                    y: 0,
                    rotateY: 90
                },
                transition: {
                    duration: 0.5
                },
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dist_modules.VerticalTimeline, {
                    layout: "1-column-left",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dist_modules.VerticalTimelineElement, {
                            className: "vertical-timeline-element--work",
                            contentStyle: {
                                background: "rgb(174, 123, 24)",
                                color: "#fff"
                            },
                            contentArrowStyle: {
                                borderRight: "7px solid  rgb(33, 150, 243)"
                            },
                            date: "mai de 2022 - mai de 2023",
                            dateClassName: "date-timeline",
                            iconStyle: {
                                background: "rgb(174, 123, 24)",
                                color: "#fff"
                            },
                            icon: /*#__PURE__*/ jsx_runtime_.jsx(md_index_esm/* MdOutlineSchool */._xL, {}),
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                    className: "vertical-timeline-element-title",
                                    children: "Froma\xe7\xe3o Desenvolvedor Full-Stack"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                    children: "Kenzie Academy Brasil"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                    className: "vertical-timeline-element-subtitle",
                                    children: "Curitiba, PR"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Desenvolvimento de aplica\xe7\xe3o web utilizando o Framework Angular 2+ (NgRx - Typescript - Sass);"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Configura\xe7\xe3o de VPS e deploy de aplica\xe7\xe3o;"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Adapta\xe7\xe3o e corre\xe7\xe3o de bugs de back-end utilizando NodeJS (Webhooks, SocketIO, Telegram API)."
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dist_modules.VerticalTimelineElement, {
                            className: "vertical-timeline-element--work",
                            contentStyle: {
                                background: "rgb(174, 123, 24)",
                                color: "#fff"
                            },
                            contentArrowStyle: {
                                borderRight: "7px solid  rgb(33, 150, 243)"
                            },
                            date: "jun de 2016 - atual",
                            dateClassName: "date-timeline",
                            iconStyle: {
                                background: "rgb(174, 123, 24)",
                                color: "#fff"
                            },
                            icon: /*#__PURE__*/ jsx_runtime_.jsx(md_index_esm/* MdOutlineSchool */._xL, {}),
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                    className: "vertical-timeline-element-title",
                                    children: "Bacharelado em Ci\xeancia e Tecnologia"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                    children: "Universiade Federal Rural do Semi-\xc1rido (UFERSA)"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                    className: "vertical-timeline-element-subtitle",
                                    children: "Mossor\xf3, RN"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Desenvolvimento de aplica\xe7\xe3o web utilizando o Framework Angular 2+ (NgRx - Typescript - Sass);"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Configura\xe7\xe3o de VPS e deploy de aplica\xe7\xe3o;"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Adapta\xe7\xe3o e corre\xe7\xe3o de bugs de back-end utilizando NodeJS (Webhooks, SocketIO, Telegram API)."
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [576,227,197], () => (__webpack_exec__(3090)));
module.exports = __webpack_exports__;

})();