(() => {
var exports = {};
exports.id = 669;
exports.ids = [669];
exports.modules = {

/***/ 8038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 8704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 7897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 6786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 9274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 2781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 1104:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ next_dist_compiled_react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_7__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2286);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5717);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8353);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7340);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9029);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2458);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4065);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_compiled_react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8378);

    const tree = {
        children: [
        '',
        {
        children: [
        'about-me',
        {
        children: ['', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 7640, 23)), "/home/jmdevbr/projetos/for_me/for_deploy_and_production/2023/março/portifolio_v3/src/app/about-me/page.tsx"],
          
        }]
      },
        {
          'head': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 647)), "/home/jmdevbr/projetos/for_me/for_deploy_and_production/2023/março/portifolio_v3/src/app/about-me/head.tsx"],
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 4838, 23)), "/home/jmdevbr/projetos/for_me/for_deploy_and_production/2023/março/portifolio_v3/src/app/layout.tsx"],
'loading': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9642)), "/home/jmdevbr/projetos/for_me/for_deploy_and_production/2023/março/portifolio_v3/src/app/loading.tsx"],
'head': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9758)), "/home/jmdevbr/projetos/for_me/for_deploy_and_production/2023/março/portifolio_v3/src/app/head.tsx"],
          
        }
      ]
      }.children;
    const pages = ["/home/jmdevbr/projetos/for_me/for_deploy_and_production/2023/março/portifolio_v3/src/app/about-me/page.tsx"];

    
    
    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
  

/***/ }),

/***/ 6215:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3902))

/***/ }),

/***/ 647:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Head)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4458);

function Head() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                children: "Sobre mim"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                content: "width=device-width, initial-scale=1",
                name: "viewport"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                name: "description",
                content: "Generated by create next app"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                rel: "stylesheet",
                href: "https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                rel: "icon",
                href: "/favicon.ico"
            })
        ]
    });
}


/***/ }),

/***/ 7640:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__ default */ const { createProxy  } = __webpack_require__(1399);
module.exports = createProxy("/home/jmdevbr/projetos/for_me/for_deploy_and_production/2023/mar\xe7o/portifolio_v3/src/app/about-me/page.tsx");


/***/ }),

/***/ 3902:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ AboutPage)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/styled-components/dist/styled-components.cjs.js
var styled_components_cjs = __webpack_require__(3103);
// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/render/dom/motion.mjs + 199 modules
var motion = __webpack_require__(925);
;// CONCATENATED MODULE: ./src/app/about-me/styles.ts


/* export const StyledAboutMeSection = styled.div` */ const StyledAboutMePage = (0,styled_components_cjs/* default */.ZP)(motion/* motion.div */.E.div)`
  width: 100%;
  height: min-content;
  .title-section {
    font-size: 1.5rem;
    margin-bottom: 2rem;
    margin-top: 2rem;
    span {
      color: var(--primary-color);
    }
  }
  .main{
    font-size: 2rem;
    margin-top: 0;
  }
  .profile-info{
    display: flex;
    flex-direction: column;
    @media (min-width:1024px){
      justify-content: space-between;
      flex-direction: row;

    }
  }
  .text-section {
    font-size: .7rem;
    line-height: 200%;
    margin-bottom: 2rem;

    @media (min-width:1024px){
      flex-basis: 60%;

    }
  }
  .personal-information {
    display: flex;
    flex-direction: column;
    margin-bottom: 2rem;
    gap: 1rem;
    p{
      font-size: .7rem;
    }
    @media (min-width:1024px){
      flex-basis: 35%;
    }
    span {
      font-weight: bold;
      color: var(--primary-color);
    }
  }
  .types-of-work {
    display: flex;
    flex-direction: column;
    @media (min-width: 1024px){
      justify-content: space-between;
      flex-direction: row;
      flex-wrap: wrap;
    }
  }
  .work-type {
    line-height: 150%;
    p{
      font-size: .7rem;
    }
    @media (min-width: 1024px){
     flex-basis: 45%;
    }
    h3 {
      margin-bottom: 0.5rem;
    }
    svg {
      color: var(--primary-color);
    }
  }
  .display-technologies{
    width: 100%;
    display: flex;
    flex-wrap: wrap;
    .icon-brand{
      h3{
        font-weight: 400;
        font-size: .8rem;
        margin-bottom: .5rem;
      }
      text-align: center;
      flex-basis: 33.3%;
      margin-bottom: 1rem;
      svg{
        border-radius: 50%;

        transition: .5s;
      }
      &:hover{
        svg{
          box-shadow: 0px 0px 34px 5px #AE7B18;
          border-radius: 50%;
        }
      }
    }
  }
`;

// EXTERNAL MODULE: ./node_modules/react-icons/md/index.esm.js
var index_esm = __webpack_require__(4348);
// EXTERNAL MODULE: ./node_modules/react-icons/tb/index.esm.js
var tb_index_esm = __webpack_require__(9130);
// EXTERNAL MODULE: ./node_modules/react-icons/fa/index.esm.js
var fa_index_esm = __webpack_require__(6775);
// EXTERNAL MODULE: ./node_modules/react-icons/si/index.esm.js
var si_index_esm = __webpack_require__(9266);
;// CONCATENATED MODULE: ./src/app/about-me/page.tsx






// import { CarouselWorksTypes } from "../carousel_works_type";
function AboutPage() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(StyledAboutMePage, {
        initial: {
            opacity: 0,
            y: 0,
            rotateY: 90
        },
        animate: {
            opacity: 1,
            y: 0,
            rotateY: 0
        },
        exit: {
            opacity: 0,
            y: 0,
            rotateY: 90
        },
        transition: {
            duration: 0.5
        },
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
                className: "section-about-me",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                        className: "title-section main",
                        children: [
                            "Sobre ",
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "Mim"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "profile-info",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-section",
                                children: "Desde de crian\xe7a que sou apaixonado pelo mundo da computa\xe7\xe3o e como sempre fui curioso por volta dos meus 18 anos comecei a estudar programa\xe7\xe3o \xe1rea pela qual me apaixonei e sigo carreira profissional. Sou uma pessoa comunicativa e provativa, busco sempre aprimorar os meus conhecimentos, vejo tudo como uma oportunidade de evolu\xe7\xe3o e busco somar ao m\xe1ximo nos ambientes no quais estou inserido."
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "personal-information",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "Idade"
                                            }),
                                            " 24"
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "Cidade"
                                            }),
                                            " Mossor\xf3,RN"
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "Email"
                                            }),
                                            " jmdevbr@gamil.com"
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
                className: "section-what-i-do",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                        className: "title-section",
                        children: [
                            "Oque ",
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "Eu Fa\xe7o"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "types-of-work",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "work-type",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* MdStore */.moe, {
                                        size: 50
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        children: "Ecommerce"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: "Como desenvolvedor Full-Stack, trabalho com o desenvolvimento de ecommerces, utilizando as mais recentes tecnologias e ferramentas para criar plataformas seguras, r\xe1pidas e f\xe1ceis de usar. Se precisa de um desenvolvedor Full-Stack para construir sua loja virtual, entre em contato comigo."
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "work-type",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* MdWeb */.BzT, {
                                        size: 50
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        children: "Landing Page"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: "Possuo ampla experi\xeancia na cria\xe7\xe3o de landing pages altamente eficazes que convertem visitantes em clientes. Eu utilizo as mais recentes tecnologias para garantir que cada p\xe1gina seja carregada rapidamente, seja totalmente responsiva e ofere\xe7a uma experi\xeancia excepcional para o usu\xe1rio em qualquer dispositivo. Se voc\xea est\xe1 procurando um desenvolvedor Full-Stack para criar sua landing page, entre em contato comigo e vamos discutir o que posso fazer para ajudar."
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "work-type",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* MdEditDocument */.fb2, {
                                        size: 50
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        children: "Landing Page"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: "Ao longo da minha carreira como desenvolvedor tamb\xe9m j\xe1 desenvolvi sites com CMS (Sistema de Gerenciamento de Conte\xfado), permitindo aos meus clientes gerenciar e atualizar seus pr\xf3prios conte\xfados. Utilizo as mais recentes tecnologias e ferramentas de CMS para garantir que cada site seja altamente funcional, seguro e f\xe1cil de usar. Minha abordagem personalizada inclui desde o design at\xe9 a configura\xe7\xe3o de plugins e recursos espec\xedficos para atender \xe0s necessidades de cada cliente. Se voc\xea precisa de um site com CMS que seja f\xe1cil de atualizar e gerenciar, entre em contato comigo e vamos discutir o que posso fazer para ajudar."
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "work-type",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* MdManageAccounts */.Y7M, {
                                        size: 50
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        children: "Sites de Gest\xe3o"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: "Trabalho com a cria\xe7\xe3o de sites para gest\xe3o de empresas. Utilizando as mais recentes tecnologias, crio plataformas personalizadas que oferecem ferramentas avan\xe7adas de gest\xe3o de neg\xf3cios, desde a an\xe1lise de dados at\xe9 a automa\xe7\xe3o de processos. Estou comprometido em fornecer solu\xe7\xf5es sob medida para ajudar as empresas a alcan\xe7ar seus objetivos de neg\xf3cios. Se voc\xea precisa de um site para gerenciamento de empresas, entre em contato comigo e vamos discutir o que posso fazer para ajudar."
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
                className: "section-technologies",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                        className: "title-section",
                        children: [
                            "Tecnologias ",
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "Utilizadas"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "display-technologies",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "icon-brand",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        children: "HTML5"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(tb_index_esm/* TbBrandHtml5 */.NgB, {
                                        size: 45
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "icon-brand",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        children: "CSS3"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(tb_index_esm/* TbBrandCss3 */.FRG, {
                                        size: 45
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "icon-brand",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        children: "JAVASCRIPT"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(tb_index_esm/* TbBrandJavascript */.Lcw, {
                                        size: 45
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "icon-brand",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        children: "REACTJS"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(tb_index_esm/* TbBrandReactNative */.KU_, {
                                        size: 45
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "icon-brand",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        children: "NEXTJS"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(tb_index_esm/* TbBrandNextjs */.cTn, {
                                        size: 45
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "icon-brand",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        children: "TAILWINDCSS"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(tb_index_esm/* TbBrandTailwind */.lVn, {
                                        size: 45
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "icon-brand",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        children: "GIT"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(tb_index_esm/* TbBrandGit */.Lr5, {
                                        size: 45
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "icon-brand",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        children: "FIREBASE"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(tb_index_esm/* TbBrandFirebase */.Py8, {
                                        size: 45
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "icon-brand",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        children: "DOCKER"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(tb_index_esm/* TbBrandDocker */.UTp, {
                                        size: 45
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "icon-brand",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        children: "ANGULAR"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(tb_index_esm/* TbBrandAngular */.ixG, {
                                        size: 45
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "icon-brand",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        children: "NODEJS"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(fa_index_esm/* FaNodeJs */.jPo, {
                                        size: 45
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "icon-brand",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        children: "POSTGRESQL"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(si_index_esm/* SiPostgresql */.u4B, {
                                        size: 45
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "icon-brand",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        children: "MONGODB"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(si_index_esm/* SiMongodb */.t$b, {
                                        size: 45
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "icon-brand",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        children: "PRISMA"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(si_index_esm/* SiPrisma */.Xlc, {
                                        size: 45
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "icon-brand",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        children: "TYPESCRIPT"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(si_index_esm/* SiTypescript */.WZi, {
                                        size: 40
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "icon-brand",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        children: "NESTJS"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(si_index_esm/* SiNestjs */.EYG, {
                                        size: 45
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "icon-brand",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        children: "EXPRESS"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(si_index_esm/* SiExpress */.AmJ, {
                                        size: 45
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "icon-brand",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        children: "FLUTTER"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(si_index_esm/* SiFlutter */.Bq1, {
                                        size: 40
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "icon-brand",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        children: "IONIC"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(si_index_esm/* SiIonic */.wNB, {
                                        size: 45
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "icon-brand",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        children: "LARAVEL"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(si_index_esm/* SiLaravel */.vn6, {
                                        size: 45
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [576,909,197], () => (__webpack_exec__(1104)));
module.exports = __webpack_exports__;

})();