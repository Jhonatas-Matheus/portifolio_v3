(() => {
var exports = {};
exports.id = 444;
exports.ids = [444];
exports.modules = {

/***/ 8038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 8704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 7897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 6786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 9274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 2781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 6150:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ next_dist_compiled_react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_7__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2286);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5717);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8353);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7340);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9029);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2458);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4065);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_compiled_react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8378);

    const tree = {
        children: [
        '',
        {
        children: [
        'portfolio',
        {
        children: ['', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3160, 23)), "/home/jmdevbr/projetos/for_me/for_deploy_and_production/2023/março/portifolio_v3/src/app/portfolio/page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 4838, 23)), "/home/jmdevbr/projetos/for_me/for_deploy_and_production/2023/março/portifolio_v3/src/app/layout.tsx"],
'loading': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9642)), "/home/jmdevbr/projetos/for_me/for_deploy_and_production/2023/março/portifolio_v3/src/app/loading.tsx"],
'head': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9758)), "/home/jmdevbr/projetos/for_me/for_deploy_and_production/2023/março/portifolio_v3/src/app/head.tsx"],
          
        }
      ]
      }.children;
    const pages = ["/home/jmdevbr/projetos/for_me/for_deploy_and_production/2023/março/portifolio_v3/src/app/portfolio/page.tsx"];

    
    
    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
  

/***/ }),

/***/ 9656:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9725))

/***/ }),

/***/ 3160:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__ default */ const { createProxy  } = __webpack_require__(1399);
module.exports = createProxy("/home/jmdevbr/projetos/for_me/for_deploy_and_production/2023/mar\xe7o/portifolio_v3/src/app/portfolio/page.tsx");


/***/ }),

/***/ 9725:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ PortifolioPage)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/render/dom/motion.mjs + 199 modules
var motion = __webpack_require__(925);
// EXTERNAL MODULE: ./node_modules/styled-components/dist/styled-components.cjs.js
var styled_components_cjs = __webpack_require__(3103);
;// CONCATENATED MODULE: ./src/app/portfolio/styles.ts


const StyledPortifolioSection = (0,styled_components_cjs/* default */.ZP)(motion/* motion.div */.E.div)`
  width: 100%;
  height: min-content;
  .title-section {
    font-size: 1.5rem;
    margin-bottom: 2rem;
    margin-top: 2rem;
    span {
      color: var(--primary-color);
    }
  }
  .main{
    font-size: 2rem;
    margin-top: 0;
  }
  .filter-portfolio {
    display: flex;
    width: 100%;
    overflow-x: auto;
    gap: 1rem;
    @media (min-width: 1024px){

      justify-content: center;
    }
    button {
      min-width: 50%;
      @media (min-width: 1024px){
        min-width: 0;
        width: auto;
      }
      /* flex-basis: 100%; */
      color: #fff;
      border-radius: 10px;
      padding: 1rem;
      border: 1px solid #fff;
      background-color: transparent;
      cursor: pointer;
      transition: 0.5s;
      &:hover {
        background-color: var(--primary-color);
      }
    }
  }
  .display-projects{
    margin-top: 1rem;
    display: flex;
    flex-wrap: wrap;
    gap: 1rem;
  }
`;

;// CONCATENATED MODULE: ./src/db/projects.json
const projects_namespaceObject = JSON.parse('[{"projectTitle":"Party Link","projectDescription":"Projeto feito em equipe composta por 5 devs onde o problema que propomos resolver era a dificuldade em encontrar comapnheiros para fazer missões coletivas em equipe missões essas que são de grande valor para os jogadores do jogo.","projectDescriptionEn":"Project made in a team composed of 5 devs where the problem we propose to solve was the difficulty in finding companions to do collective team missions, missions that are of great value to the game\'s players.","projeectTechs":["NextJS","TailwindCSS","Firebase"],"projectImg":"/party-link.png","projectLink":"https://party-link-2g7w9wplc-party-link.vercel.app/","solo":false},{"projectTitle":"Hamburgeria","projectDescription":"Projeto feito com a proposta de simular um menu online onde poder ser feito pedidos de um restaurante com tema de hamburgeria","projectDescriptionEn":"Project made with the proposal to simulate an online menu where orders can be made from a hamburger-themed restaurant","projeectTechs":["ReactJS"],"projectLink":"https://kenzie-hamburgeria-b14edxer2-jhonatas-matheus.vercel.app/","projectImg":"/hamburgeria.png","solo":true},{"projectTitle":"Miniblog","projectDescription":"Projeto feito com a proposta de simular uma pequena rede social onde as pessoas podem compartilhar imagens que acham bonitas.","projectDescriptionEn":"Project made with the proposal to simulate a small social network where people can share images they find beautiful.","projeectTechs":["Typescript","Styled-Components","Firebase"],"projectImg":"/miniblog.png","projectLink":"https://miniblog-with-typescript.vercel.app/"},{"projectTitle":"TechsHub","projectDescription":"Projeto feito com intuito de simular um portifólio de tecnologias consumindo api externa com axios.","projectDescriptionEn":"Project made in order to simulate a portfolio of technologies consuming external api with axios.","projeectTechs":["ReactJS","Typescript","Styled-Components","Axios","React Router Dom","Context API"],"projectImg":"/techs-hub.png","projectLink":"https://techs-hub.vercel.app/"},{"projectTitle":"Party Link","projectDescription":"Projeto feito em equipe composta por 5 devs onde o problema que propomos resolver era a dificuldade em encontrar comapnheiros para fazer missões coletivas em equipe missões essas que são de grande valor para os jogadores do jogo.","projectDescriptionEn":"Project made in a team composed of 5 devs where the problem we propose to solve was the difficulty in finding companions to do collective team missions, missions that are of great value to the game\'s players.","projeectTechs":["NextJS","TailwindCSS","Firebase"],"projectImg":"/party-link.png","projectLink":"https://party-link-2g7w9wplc-party-link.vercel.app/","solo":false},{"projectTitle":"Hamburgeria","projectDescription":"Projeto feito com a proposta de simular um menu online onde poder ser feito pedidos de um restaurante com tema de hamburgeria","projectDescriptionEn":"Project made with the proposal to simulate an online menu where orders can be made from a hamburger-themed restaurant","projeectTechs":["ReactJS"],"projectLink":"https://kenzie-hamburgeria-b14edxer2-jhonatas-matheus.vercel.app/","projectImg":"/hamburgeria.png","solo":true},{"projectTitle":"Miniblog","projectDescription":"Projeto feito com a proposta de simular uma pequena rede social onde as pessoas podem compartilhar imagens que acham bonitas.","projectDescriptionEn":"Project made with the proposal to simulate a small social network where people can share images they find beautiful.","projeectTechs":["Typescript","Styled-Components","Firebase"],"projectImg":"/miniblog.png","projectLink":"https://miniblog-with-typescript.vercel.app/"},{"projectTitle":"TechsHub","projectDescription":"Projeto feito com intuito de simular um portifólio de tecnologias consumindo api externa com axios.","projectDescriptionEn":"Project made in order to simulate a portfolio of technologies consuming external api with axios.","projeectTechs":["ReactJS","Typescript","Styled-Components","Axios","React Router Dom","Context API"],"projectImg":"/techs-hub.png","projectLink":"https://techs-hub.vercel.app/"}]');
;// CONCATENATED MODULE: ./src/components/card_project_portfolio/styles.ts

const StyledCardProject = styled_components_cjs/* default.div */.ZP.div`
  width: 100%;
  flex-basis: 100%;
  @media (min-width: 1024px){
    flex-basis: 30%;
  }
  &:hover{
    .photo-frame{
      box-shadow: 0px 0px 34px 11px #AE7B18;
    }
  }
  h2{
    text-align: center;
    margin-bottom: 1rem;
  }
  .photo-frame {
    width: 100%;
    height: 10rem;
    transition: .5s;
    img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }
  }
`;

;// CONCATENATED MODULE: ./src/components/card_project_portfolio/index.tsx


const CardProjectPortfolio = ({ project  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(StyledCardProject, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                children: project.projectTitle
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "photo-frame",
                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                    src: project.projectImg,
                    alt: ""
                })
            })
        ]
    });
};

;// CONCATENATED MODULE: ./src/app/portfolio/page.tsx




function PortifolioPage() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(StyledPortifolioSection, {
        initial: {
            opacity: 0,
            y: 0,
            rotateY: 90
        },
        animate: {
            opacity: 1,
            y: 0,
            rotateY: 0
        },
        exit: {
            opacity: 0,
            y: 0,
            rotateY: 90
        },
        transition: {
            duration: 0.5
        },
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                className: "title-section main",
                children: [
                    "Meu ",
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: "Portf\xf3lio"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "filter-portfolio",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        children: "ReactJS"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        children: "Angular"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        children: "Express"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        children: "NestJS"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        children: "SpringBoot"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "display-projects",
                children: projects_namespaceObject.map((project)=>/*#__PURE__*/ jsx_runtime_.jsx(CardProjectPortfolio, {
                        project: project
                    }, project.projectTitle))
            })
        ]
    });
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [576,197], () => (__webpack_exec__(6150)));
module.exports = __webpack_exports__;

})();